To run the neural network:
1. cd src
2. javac opt/test/AbaloneTest.java
3. java opt.test.AbaloneTest

To run the Four Peaks test:
1. cd src.
2. javac opt/test/FourPeaksTest.java
3. java opt.test.FourPeaksTest

To run the Knapsack test:
1. cd src.
2. javac opt/test/KnapsackTest.java
3. java opt.test.KnapsackTest

To run the Count Ones test:
1. cd src.
2. javac opt/test/CountOnesTest.java
3. java opt.test.CountOnesTest